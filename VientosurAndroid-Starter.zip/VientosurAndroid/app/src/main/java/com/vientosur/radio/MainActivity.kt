package com.vientosur.radio

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var hostInput: EditText
    private lateinit var portInput: EditText
    private lateinit var mountInput: EditText
    private lateinit var userInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var statusText: TextView

    private val prefs by lazy {
        getSharedPreferences("vientosur_settings", Context.MODE_PRIVATE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildInterface()
        loadSavedSettings()
    }

    private fun buildInterface() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(24))
            setBackgroundColor(0xFFF5F7FA.toInt())
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)

        val brand = TextView(this).apply {
            text = "VIENTOSUR"
            textSize = 27f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF123B50.toInt())
        }
        content.addView(brand)

        content.addView(text(
            "Consola de radio por Internet",
            16f, 0xFF52636D.toInt()
        ).apply { setPadding(0, dp(3), 0, dp(18)) })

        content.addView(sectionTitle("Servidor Icecast"))

        hostInput = field("Servidor (ej. radio.midominio.com)", "radio.example.com")
        portInput = field("Puerto", "8000").apply { inputType = 2 }
        mountInput = field("Punto de montaje (ej. /directo.mp3)", "/stream.mp3")
        userInput = field("Usuario de emisión", "source")
        passwordInput = field("Contraseña de emisión", "").apply {
            inputType = 129 // textPassword
        }

        content.addView(hostInput)
        content.addView(portInput)
        content.addView(mountInput)
        content.addView(userInput)
        content.addView(passwordInput)

        val saveButton = Button(this).apply {
            text = "Validar y guardar configuración"
            setOnClickListener { validateAndSave() }
        }
        content.addView(saveButton, matchWrap())

        statusText = text(
            "Estado: configuración pendiente.\nLa emisión de audio todavía no está implementada en esta versión inicial.",
            14f, 0xFF7A4B00.toInt()
        ).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFFFFF0D5.toInt())
        }
        val statusParams = matchWrap().apply {
            topMargin = dp(14)
            bottomMargin = dp(10)
        }
        content.addView(statusText, statusParams)

        content.addView(text(
            "Versión inicial 0.1.0 · La contraseña no se guarda en el dispositivo en esta versión.",
            12f, 0xFF63727B.toInt()
        ).apply { setPadding(0, dp(8), 0, dp(4)) })

        page.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))
        setContentView(page)
    }

    private fun validateAndSave() {
        val host = hostInput.text.toString().trim()
        val port = portInput.text.toString().trim().toIntOrNull()
        val mount = mountInput.text.toString().trim()
        val username = userInput.text.toString().trim()

        if (host.isBlank()) {
            hostInput.error = "Introduce el nombre del servidor"
            return
        }
        if (port == null || port !in 1..65535) {
            portInput.error = "El puerto debe estar entre 1 y 65535"
            return
        }
        if (!mount.startsWith("/") || mount.length < 2) {
            mountInput.error = "El punto de montaje debe comenzar con /"
            return
        }
        if (username.isBlank()) {
            userInput.error = "Introduce el usuario de emisión"
            return
        }

        prefs.edit()
            .putString("host", host)
            .putInt("port", port)
            .putString("mount", mount)
            .putString("username", username)
            .apply()

        statusText.text =
            "Configuración validada y guardada localmente.\n" +
            "Servidor: $host:$port$mount\n\n" +
            "Importante: esto solo valida los campos; todavía no prueba la conexión ni transmite audio."
        statusText.setTextColor(0xFF175C37.toInt())
        statusText.setBackgroundColor(0xFFE0F4E8.toInt())
        Toast.makeText(this, "Configuración guardada", Toast.LENGTH_SHORT).show()
    }

    private fun loadSavedSettings() {
        hostInput.setText(prefs.getString("host", ""))
        val port = prefs.getInt("port", 8000)
        portInput.setText(port.toString())
        mountInput.setText(prefs.getString("mount", "/stream.mp3"))
        userInput.setText(prefs.getString("username", "source"))
        // Deliberadamente no se persiste ni restaura la contraseña.
    }

    private fun field(label: String, hintValue: String): EditText {
        return EditText(this).apply {
            hint = label
            if (hintValue.isNotEmpty()) setText(hintValue)
            textSize = 16f
            singleLine = true
            setPadding(dp(12), dp(7), dp(12), dp(7))
            layoutParams = matchWrap().apply { bottomMargin = dp(8) }
        }
    }

    private fun sectionTitle(value: String) = text(
        value, 18f, 0xFF123B50.toInt()
    ).apply {
        setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(6), 0, dp(8))
    }

    private fun text(value: String, size: Float, color: Int) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
        }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
